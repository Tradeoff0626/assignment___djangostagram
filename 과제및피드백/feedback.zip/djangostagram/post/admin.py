from django.contrib import admin

from .models import Post


# Register your models here.
class PostAdmin(admin.ModelAdmin):
  '''
    Python에서 들여쓰기는 2칸, 4칸을 띄어쓰거나, 탭키를 사용할 수 있는데,
    pep8에선 코딩스타일로 4칸 띄어쓰기를 권장합니다.

    참고 : pep8 coding convention
  '''
  list_display = ('contents',)

admin.site.register(Post, PostAdmin)