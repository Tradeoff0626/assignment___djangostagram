from django import forms
from django.contrib.auth.hashers import check_password

from .models import Dsuser

'''
    import 문과 코드 본문 시작 줄은 2줄 띄어쓰기를 기본으로 합니다.
    그렇게 하시지 않으셔도 동작엔 전혀 문제가 없지만, 
    다른 사람들과 협업시에 가독성을 높히기 위한 규칙입니다.
    참고 : pep8 coding convention
    
'''

class LoginForm(forms.Form):
  userid = forms.CharField(
							error_messages={
								'required': '아이디를 입력해주세요.'
							},
    					max_length=64, label="아이디")
  password = forms.CharField(
    					error_messages={
								'required': '비밀번호를 입력해주세요.'
							},
         			max_length=64, widget=forms.PasswordInput, label="비밀번호")
  
  # 추가 유효성 검사
  def clean(self):
    clean_data = super().clean()		# 상속 받은 기본 clean 데이터
    userid = clean_data.get('userid')
    password = clean_data.get('password')
    
    if userid and password:
      try:
        dsuser = Dsuser.objects.get(userid=userid)
      except Dsuser.DoesNotExist:
        self.add_error('userid', '아이디가 없습니다.')
        return
        
      if not check_password(password, dsuser.password):
        self.add_error('password', '비밀번호를 틀렸습니다.')
      else:
        self.user_id = dsuser.id