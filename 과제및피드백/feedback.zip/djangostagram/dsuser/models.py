from django.db import models

'''
    import 문과 코드 본문 시작 줄은 2줄 띄어쓰기를 기본으로 합니다.
    그렇게 하시지 않으셔도 동작엔 전혀 문제가 없지만, 
    다른 사람들과 협업시에 가독성을 높히기 위한 규칙입니다.
    참고 : pep8 coding convention
    
'''

# Create your models here.
class Dsuser(models.Model):
  userid = models.CharField(max_length=64,
                              verbose_name='아이디')
  useremail = models.EmailField(max_length=128,
                              verbose_name='이메일')
  password = models.CharField(max_length=64,
                              verbose_name='비밀번호')
  registered_dttm = models.DateTimeField(auto_now_add=True,
                                         verbose_name='가입일')
  
  def __str__(self):				# admin 페이지에 보여줄 문자열
			return self.userid
  
  class Meta:
    db_table = 'djangostagram_dsuser'
    verbose_name = '장고스타그램 사용자'					# 클래스명 대신 표시할 문자 
    verbose_name_plural = '장고스타그램 사용자'		# 클래스명 대신 표시할 문자(복수)