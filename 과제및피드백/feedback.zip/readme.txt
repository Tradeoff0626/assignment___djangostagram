* 계정정보 (비밀번호 1234)
 - 관리자 : admin
 - 사용자 : usr01, usr02, usr03

* pythonanywhere 배포 주소
; tradeoff.pythonanywhere.com