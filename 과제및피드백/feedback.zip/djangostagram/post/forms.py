from django import forms
# from .models import Post

'''
    import 문과 코드 본문 시작 줄은 2줄 띄어쓰기를 기본으로 합니다.
    그렇게 하시지 않으셔도 동작엔 전혀 문제가 없지만, 
    다른 사람들과 협업시에 가독성을 높히기 위한 규칙입니다.
    참고 : pep8 coding convention
    
'''

class PostForm(forms.Form):
  imageurl = forms.CharField(
							error_messages={
								'required': '이미지 주소를 입력해주세요.'
							},
    					max_length=512, label="이미지 주소")
  contents = forms.CharField(
    					error_messages={
								'required': '내용을 입력해주세요.'
							},
         			widget=forms.Textarea, label="내용")
  tags = forms.CharField(
         			required=False, label="태그",)